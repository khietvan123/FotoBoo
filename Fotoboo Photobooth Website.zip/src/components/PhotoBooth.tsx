import { useState, useRef, useEffect } from 'react';
import { Camera, ArrowLeft, Download, Check, Edit, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { toast } from 'sonner@2.0.3';
import { PhotoStripEditor } from './PhotoStripEditor';

interface PhotoBoothProps {
  onBackHome: () => void;
}

type CaptureState = 'ready' | 'countdown' | 'capturing' | 'preview' | 'selecting' | 'complete' | 'editing';

export function PhotoBooth({ onBackHome }: PhotoBoothProps) {
  const [state, setState] = useState<CaptureState>('ready');
  const [countdown, setCountdown] = useState(7);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([]);
  const [selectedPhotos, setSelectedPhotos] = useState<number[]>([]);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Update video stream when stream changes
  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  // Don't cleanup stream on unmount - keep it active for multiple sessions
  useEffect(() => {
    return () => {
      // Only cleanup on component unmount (going back to home)
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Countdown timer
  useEffect(() => {
    if (state === 'countdown') {
      if (countdown > 0) {
        const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
        return () => clearTimeout(timer);
      } else {
        capturePhoto();
      }
    }
  }, [countdown, state]);

  const startCapture = async () => {
    // Request camera access when user clicks start
    if (!stream) {
      try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480, facingMode: 'user' }
        });
        setStream(mediaStream);
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
        }
        setCameraError(null);
        
        // Wait a bit for video to load before starting countdown
        setTimeout(() => {
          setState('countdown');
          setCountdown(7);
          setCurrentPhotoIndex(0);
          setCapturedPhotos([]);
          setSelectedPhotos([]);
        }, 500);
      } catch (error) {
        let errorMsg = 'Unable to access camera.';
        
        if (error instanceof Error) {
          if (error.name === 'NotAllowedError') {
            errorMsg = 'Camera permission denied. Please allow camera access and try again.';
          } else if (error.name === 'NotFoundError') {
            errorMsg = 'No camera found. Please connect a camera and try again.';
          } else if (error.name === 'NotReadableError') {
            errorMsg = 'Camera is in use by another app. Please close other apps and try again.';
          }
        }
        
        setCameraError(errorMsg);
        toast.error(errorMsg);
      }
    } else {
      setState('countdown');
      setCountdown(7);
      setCurrentPhotoIndex(0);
      setCapturedPhotos([]);
      setSelectedPhotos([]);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext('2d');

      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0);
        const photoData = canvas.toDataURL('image/png');
        
        const newPhotos = [...capturedPhotos, photoData];
        setCapturedPhotos(newPhotos);
        
        // Show preview of captured photo
        setState('preview');
        
        // After 2 seconds, continue to next photo or selection
        setTimeout(() => {
          if (currentPhotoIndex < 3) {
            // More photos to capture
            setCurrentPhotoIndex(currentPhotoIndex + 1);
            setCountdown(7);
            setState('countdown');
          } else {
            // All photos captured
            setState('selecting');
            toast.success('All photos captured! Select 4 for your photo strip.');
          }
        }, 2000);
      }
    }
  };

  const removePhoto = (index: number) => {
    setCapturedPhotos(prev => prev.filter((_, i) => i !== index));
    setSelectedPhotos(prev => {
      const newSelected = prev.filter(i => i !== index);
      return newSelected.map(i => i > index ? i - 1 : i);
    });
    toast.success('Photo removed');
  };

  const togglePhotoSelection = (index: number) => {
    if (selectedPhotos.includes(index)) {
      setSelectedPhotos(selectedPhotos.filter(i => i !== index));
    } else {
      if (selectedPhotos.length < 4) {
        setSelectedPhotos([...selectedPhotos, index]);
      } else {
        toast.error('You can only select 4 photos');
      }
    }
  };

  const retakeSinglePhoto = () => {
    // Allow user to capture one more photo
    setState('countdown');
    setCountdown(7);
    setCurrentPhotoIndex(capturedPhotos.length);
  };

  const finishSelection = () => {
    if (selectedPhotos.length !== 4) {
      toast.error('Please select exactly 4 photos');
      return;
    }
    setState('complete');
  };

  const downloadPhotoStrip = () => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (context) {
        // Photo strip dimensions with white borders (like polaroid)
        const padding = 30; // White border padding
        const photoPadding = 15; // Space between photos
        const stripWidth = 400;
        const photoWidth = stripWidth - (padding * 2);
        const photoHeight = 240; // Each photo height
        const bottomSpace = 60; // Extra space at bottom for branding
        const stripHeight = (padding * 2) + (photoHeight * 4) + (photoPadding * 3) + bottomSpace;
        
        canvas.width = stripWidth;
        canvas.height = stripHeight;
        
        // White background for entire strip
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, stripWidth, stripHeight);
        
        // Counter for loaded images
        let loadedCount = 0;
        
        // Draw selected photos with spacing
        selectedPhotos.forEach((photoIndex, i) => {
          const img = new Image();
          img.src = capturedPhotos[photoIndex];
          img.onload = () => {
            const yPosition = padding + (i * (photoHeight + photoPadding));
            context.drawImage(img, padding, yPosition, photoWidth, photoHeight);
            
            loadedCount++;
            
            // Add Fotoboo branding after last image is loaded
            if (loadedCount === 4) {
              context.fillStyle = '#9333ea';
              context.font = '28px Pacifico, cursive';
              context.textAlign = 'center';
              context.fillText('Fotoboo', stripWidth / 2, stripHeight - 25);
              
              // Download
              const link = document.createElement('a');
              link.download = `fotoboo-${Date.now()}.png`;
              link.href = canvas.toDataURL('image/png');
              link.click();
              toast.success('Photo strip downloaded!');
            }
          };
        });
      }
    }
  };

  const retakePhotos = () => {
    // Keep the stream active, just reset to ready
    setCapturedPhotos([]);
    setSelectedPhotos([]);
    setCurrentPhotoIndex(0);
    if (stream) {
      setState('countdown');
      setCountdown(7);
    } else {
      setState('ready');
    }
  };

  const openEditor = () => {
    setState('editing');
  };

  const backFromEditor = () => {
    setState('complete');
  };

  // Show editor if in editing state
  if (state === 'editing') {
    const selectedPhotoData = selectedPhotos.map(index => capturedPhotos[index]);
    return <PhotoStripEditor photos={selectedPhotoData} onBack={backFromEditor} />;
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            onClick={onBackHome}
            variant="ghost"
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Home
          </Button>
          <h1 className="text-4xl text-white">Fotoboo</h1>
          <div className="w-32" /> {/* Spacer for centering */}
        </div>

        {/* Camera Error Alert */}
        {cameraError && (
          <Card className="p-4 bg-red-500/20 border-red-500/50 mb-6">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white">
                !
              </div>
              <div className="flex-1">
                <h3 className="text-white mb-1">Camera Access Required</h3>
                <p className="text-white/90 text-sm">{cameraError}</p>
              </div>
            </div>
          </Card>
        )}

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Camera/Preview Panel */}
          <Card className="p-6 bg-white/10 backdrop-blur-md border-white/20">
            <div className="space-y-4">
              <h2 className="text-2xl text-white text-center">
                {state === 'ready' && 'Ready to Start'}
                {state === 'countdown' && `Photo ${currentPhotoIndex + 1} of 4`}
                {state === 'capturing' && 'Capturing...'}
                {state === 'preview' && 'Photo Captured!'}
                {state === 'selecting' && 'Select Your Photos'}
                {state === 'complete' && 'Your Photo Strip'}
              </h2>

              {/* Countdown Display - Above Camera */}
              {state === 'countdown' && stream && (
                <div className="text-center mb-4">
                  <p className="text-white text-2xl">
                    Photo {currentPhotoIndex + 1} of 4 in <span className="text-4xl animate-pulse">{countdown}</span>s
                  </p>
                </div>
              )}

              {/* Photo Preview - Show during preview state */}
              {state === 'preview' && capturedPhotos.length > 0 && (
                <div className="w-full rounded-lg overflow-hidden">
                  <img 
                    src={capturedPhotos[capturedPhotos.length - 1]} 
                    alt="Captured preview" 
                    className="w-full"
                  />
                </div>
              )}

              {/* Camera Feed */}
              {(state === 'ready' || state === 'countdown') && (
                <div className="w-full">
                  {!stream ? (
                    <div className="w-full aspect-video rounded-lg bg-black/50 flex items-center justify-center">
                      <div className="text-center text-white/60">
                        <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
                        <p>Click "Start Capture" to enable camera</p>
                      </div>
                    </div>
                  ) : cameraError ? (
                    <div className="w-full aspect-video rounded-lg bg-red-500/20 border-2 border-red-500/50 flex flex-col items-center justify-center p-6">
                      <div className="text-center text-white">
                        <Camera className="w-16 h-16 mx-auto mb-4" />
                        <p className="mb-2 text-lg">{cameraError}</p>
                        <div className="mt-4 space-y-2 text-sm text-white/90 max-w-md">
                          <p>To fix this:</p>
                          <ol className="text-left list-decimal list-inside space-y-1">
                            <li>Click the camera icon in your browser's address bar</li>
                            <li>Select "Allow" for camera access</li>
                            <li>Click "Try Again" below</li>
                          </ol>
                        </div>
                      </div>
                      <Button
                        onClick={() => {
                          setCameraError(null);
                          startCapture();
                        }}
                        className="mt-4 bg-white hover:bg-white/90"
                        style={{ color: '#44318D' }}
                      >
                        Try Again
                      </Button>
                    </div>
                  ) : (
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full rounded-lg bg-black"
                    />
                  )}
                </div>
              )}

              {/* Progress */}
              {state === 'countdown' && (
                <div className="space-y-2">
                  <Progress value={((7 - countdown) / 7) * 100} className="h-2" />
                </div>
              )}

              {/* Start Button */}
              {state === 'ready' && (
                <Button
                  onClick={startCapture}
                  className="w-full bg-white hover:bg-white/90 py-6 gap-2"
                  style={{ color: '#44318D' }}
                >
                  <Camera className="w-6 h-6" />
                  {stream ? 'Start Capture (4 Photos)' : 'Enable Camera & Start'}
                </Button>
              )}

              {/* Retake Button */}
              {(state === 'selecting' || state === 'complete') && (
                <Button
                  onClick={retakePhotos}
                  className="w-full bg-white hover:bg-white/90 py-4"
                  style={{ color: '#44318D' }}
                >
                  Retake Photos
                </Button>
              )}
            </div>
          </Card>

          {/* Photos Panel */}
          <Card className="p-6 bg-white/10 backdrop-blur-md border-white/20">
            <h3 className="text-xl text-white mb-4">Captured Photos</h3>
            
            {capturedPhotos.length === 0 && (
              <div className="text-center text-white/60 py-16">
                No photos captured yet
              </div>
            )}

            {/* Photo Grid - Show during all capture states */}
            {capturedPhotos.length > 0 && (state === 'ready' || state === 'countdown' || state === 'preview' || state === 'selecting') && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  {capturedPhotos.map((photo, index) => (
                    <div
                      key={index}
                      className={`relative rounded-lg overflow-hidden border-4 transition-all group ${
                        state === 'selecting' && selectedPhotos.includes(index)
                          ? 'border-green-400 scale-95'
                          : 'border-white/20 hover:border-white/40'
                      }`}
                    >
                      <img 
                        src={photo} 
                        alt={`Captured ${index + 1}`} 
                        className={`w-full ${state === 'selecting' ? 'cursor-pointer' : ''}`}
                        onClick={() => state === 'selecting' && togglePhotoSelection(index)}
                      />
                      {/* Delete button - only show during selection */}
                      {state === 'selecting' && (
                        <button
                          onClick={() => removePhoto(index)}
                          className="absolute top-2 left-2 bg-red-500 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity z-10"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                      {state === 'selecting' && selectedPhotos.includes(index) && (
                        <div className="absolute inset-0 bg-green-400/30 flex items-center justify-center pointer-events-none">
                          <div className="bg-green-400 rounded-full p-2">
                            <Check className="w-6 h-6 text-white" />
                          </div>
                          <div className="absolute top-2 right-2 bg-green-400 text-white rounded-full w-8 h-8 flex items-center justify-center">
                            {selectedPhotos.indexOf(index) + 1}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {state === 'selecting' && (
                  <>
                    <div className="text-center text-white text-sm">
                      Selected: {selectedPhotos.length} / 4
                    </div>

                    <div className="space-y-2">
                      <Button
                        onClick={finishSelection}
                        disabled={selectedPhotos.length !== 4}
                        className="w-full bg-green-500 hover:bg-green-600 text-white py-6"
                        style={{ fontFamily: 'Pacifico, cursive' }}
                      >
                        Create Photo Strip
                      </Button>

                      <Button
                        onClick={retakeSinglePhoto}
                        className="w-full bg-white hover:bg-white/90 py-4"
                        style={{ color: '#44318D' }}
                      >
                        <Camera className="w-4 h-4 mr-2" />
                        Capture Another Photo
                      </Button>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* Photo Strip Preview */}
            {state === 'complete' && (
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-lg shadow-2xl max-w-xs mx-auto">
                  <div className="space-y-3">
                    {selectedPhotos.map((photoIndex, i) => (
                      <div key={i} className="w-full">
                        <img
                          src={capturedPhotos[photoIndex]}
                          alt={`Strip ${i + 1}`}
                          className="w-full rounded-sm"
                        />
                      </div>
                    ))}
                    <div className="pt-3 text-center">
                      <p className="text-purple-600">Fotoboo</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={openEditor}
                    className="flex-1 bg-white hover:bg-white/90 py-6 gap-2"
                    style={{ color: '#44318D' }}
                  >
                    <Edit className="w-6 h-6" />
                    Customize
                  </Button>
                  <Button
                    onClick={downloadPhotoStrip}
                    className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-6 gap-2"
                  >
                    <Download className="w-6 h-6" />
                    Download
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </div>

        {/* Hidden canvas for photo capture and strip generation */}
        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
}
