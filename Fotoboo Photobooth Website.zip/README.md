
  # Fotoboo Photobooth Website

  This is a code bundle for Fotoboo Photobooth Website. The original project is available at https://www.figma.com/design/okuhGFNKTNVENCBhoEw3zv/Fotoboo-Photobooth-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  